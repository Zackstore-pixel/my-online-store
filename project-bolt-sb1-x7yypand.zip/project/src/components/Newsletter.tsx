import React, { useState } from 'react';
import { Mail } from 'lucide-react';

export default function Newsletter() {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setEmail('');
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {!isSubmitted ? (
        <div className="bg-white p-6 rounded-lg shadow-lg max-w-md">
          <div className="flex items-center mb-4">
            <Mail className="h-6 w-6 text-indigo-600" />
            <h3 className="ml-2 text-lg font-medium text-gray-900">Subscribe to Our Newsletter</h3>
          </div>
          <p className="text-sm text-gray-600 mb-4">
            Get 10% off your first purchase and stay updated with our latest offers!
          </p>
          <form onSubmit={handleSubmit} className="flex">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              className="flex-1 px-4 py-2 border border-gray-300 rounded-l-md focus:ring-indigo-500 focus:border-indigo-500"
              required
            />
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 text-white rounded-r-md hover:bg-indigo-700"
            >
              Subscribe
            </button>
          </form>
        </div>
      ) : (
        <div className="bg-green-100 p-6 rounded-lg shadow-lg">
          <p className="text-green-800">Thanks for subscribing!</p>
        </div>
      )}
    </div>
  );
}